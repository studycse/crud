-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2020 at 06:59 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register2`
--

-- --------------------------------------------------------

--
-- Table structure for table `registertable2`
--

CREATE TABLE `registertable2` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `upozila` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `sscversity` varchar(255) NOT NULL,
  `sscboard` varchar(255) NOT NULL,
  `sscresult` varchar(255) NOT NULL,
  `hscversity` varchar(255) NOT NULL,
  `hscboard` varchar(255) NOT NULL,
  `hscresult` varchar(255) NOT NULL,
  `gdversity` varchar(255) NOT NULL,
  `gdboard` varchar(255) NOT NULL,
  `gdresult` varchar(255) NOT NULL,
  `msversity` varchar(255) NOT NULL,
  `msboard` varchar(255) NOT NULL,
  `msresult` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registertable2`
--

INSERT INTO `registertable2` (`id`, `username`, `email`, `address`, `mobile`, `division`, `district`, `upozila`, `language`, `sscversity`, `sscboard`, `sscresult`, `hscversity`, `hscboard`, `hscresult`, `gdversity`, `gdboard`, `gdresult`, `msversity`, `msboard`, `msresult`, `image`, `file`) VALUES
(50, 'Samia Rahman', '123@gmail.com', 'ssssss', '0131932743', 'Dhaka', 'Tangail', 'Donia', 'on', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '0', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '3.00', '', ''),
(51, 'Samia Rahman', '123@gmail.com', 'ssssss', '0131932743', 'Dhaka', 'Tangail', 'Donia', 'on', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '0', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '3.00', '', ''),
(55, 'mita', 'aallliiiii@gmail.com', 'dddddasdsasa', '0196885288', 'Dhaka', 'Tangail', 'Donia', 'on', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', '', ''),
(56, 'mita', 'aallliiiii@gmail.com', 'dddddasdsasa', '0196885288', 'Dhaka', 'Tangail', 'Donia', 'on', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', '', ''),
(62, 'Samia Rahman', '123@gmail.com', 'sssssssss', '0131932743', 'Dhaka', 'Tangail', 'Donia', 'on', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'e282450089.jpg', 'images (1).jpg'),
(63, 'Samia Rahman', '123@gmail.com', 'ssssssssss', '0131932743', 'Dhaka', 'Tangail', 'Donia', 'on', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'UIU', 'Comilla', '4.00', 'images (2).jpg', 'Daily-Sun-49-01-16-08-2017.jpg'),
(64, 'Samia Rahman', '123@gmail.com', 'sssssssss', '0131932743', 'Dhaka', 'Tangail', 'Donia', 'on', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '3.00', 'DCC', 'Comilla', '2.00', 'images (2).jpg', 'id.pdf'),
(66, 'Samia Rahman', '123@gmail.com', 'ssssssss', '0131932743', 'Dhaka', 'Tangail', 'Donia', 'on', 'DCC', 'comilla', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '3.00', 'UIU', 'CTG', '3.00', '', ''),
(76, '', '', '', '', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '6.jpg', ''),
(77, 'Samia Rahman', '123@gmail.com', 'ssssss', '0131932743', 'Dhaka', 'Tangail', 'Dhanmondi', 'on', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '3.00', '', ''),
(78, 'Samia Rahman', '123@gmail.com', 'ssssss', '0131932743', 'Dhaka', 'Tangail', 'Dhanmondi', 'on', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'Dhaka', '3.00', '7.jpg', ''),
(81, 'Samia Rahman', '123@gmail.com', 'sssssssssss', '0131932743', 'Dhaka', 'Tangail', 'Dhanmondi', 'on', 'DCC', 'Dhaka', '4.00', 'UIU', 'comilla', '4.00', 'MIST', 'CTG', '4.00', 'DCC', 'Dhaka', '4.00', '8.jpg', ''),
(82, 'Samia Rahman', '123@gmail.com', 'ssssssssss', '0131932743', 'Dhaka', 'Narayanganj', 'Dhanmondi', 'on', 'DCC', 'Dhaka', '4.00', 'UIU', 'Dhaka', '3.00', 'UIU', 'comilla', '3.00', 'MIST', 'CTG', '2.00', '', ''),
(83, 'Samia Rahman', '123@gmail.com', 'ssssssssss', '0131932743', 'Dhaka', 'Narayanganj', 'Dhanmondi', 'on', 'DCC', 'Dhaka', '4.00', 'UIU', 'Dhaka', '3.00', 'UIU', 'comilla', '3.00', 'MIST', 'CTG', '2.00', '9.jpg', ''),
(86, 'Samia Rahman', '123@gmail.com', 'sssssssss', '0131932743', 'Dhaka', 'Tangail', 'Donia', 'on', 'DCC', 'Dhaka', '4.00', 'UIU', 'Dhaka', '3.00', 'MIST', 'comilla', '3.00', 'MIST', 'CTG', '4.00', '10.jpg', ''),
(87, 'Samia Rahman', '123@gmail.com', 'ddddffgfg', '0196885288', 'Dhaka', 'Narayanganj', 'Sonir', 'on', 'DCC', 'comilla', '4.00', 'DCC', 'Dhaka', '4.00', 'DCC', 'CTG', '3.00', 'UIU', 'Dhaka', '4.00', '11.jpg', ''),
(110, '', '', '', '', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', ''),
(112, '', '', '', '', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', ''),
(113, '', '', '', '', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `training`
--

CREATE TABLE `training` (
  `id` int(11) NOT NULL,
  `ref_master_id` int(11) NOT NULL,
  `training_name` varchar(200) NOT NULL,
  `organization` varchar(200) DEFAULT NULL,
  `details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `training`
--

INSERT INTO `training` (`id`, `ref_master_id`, `training_name`, `organization`, `details`) VALUES
(0, 0, 'aaaa', '', ''),
(1, 50, 'HTML', 'BIG M', 'okkk'),
(2, 50, 'css', NULL, NULL),
(3, 55, 'php', NULL, NULL),
(4, 113, 'java', 'orga', 'detail');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registertable2`
--
ALTER TABLE `registertable2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `training`
--
ALTER TABLE `training`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registertable2`
--
ALTER TABLE `registertable2`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
